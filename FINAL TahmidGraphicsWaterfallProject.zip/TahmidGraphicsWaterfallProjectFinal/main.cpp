#include <windows.h>
#include <cstdio>
#include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>
#include <mmsystem.h>

#define PI 3.1416

// ANIMATION VARIABLES
GLfloat birdPosition = -1.2f;
GLfloat cloudPosition = -1.2f;
GLfloat waterFallPos = 0.0f;
GLfloat riverPos = 0.0f;

// RAIN TOGGLE
bool isRaining = false;
GLfloat rainPos = 0.0f;

// ANIMATION SPEEDS
GLfloat birdSpeed = 0.006f;
GLfloat cloudSpeed = 0.003f;
GLfloat waterSpeed = 0.015f;
GLfloat riverSpeed = 0.005f;
GLfloat rainSpeed = 0.05f;

// KEYBOARD
void handleKeypress(unsigned char key, int x, int y)
{
    switch (key)
    {
    case 'r':
        isRaining = !isRaining;
        break;
    case 'R':
        isRaining = !isRaining;
        break;
    }
    glutPostRedisplay();
}

// TIMER UPDATE
void update(int value)
{

    cloudPosition += cloudSpeed;
    if (cloudPosition > 1.5f) cloudPosition = -1.5f;

    birdPosition += birdSpeed;
    if (birdPosition > 1.5f) birdPosition = -1.5f;

    waterFallPos -= waterSpeed;
    if (waterFallPos < -0.5f) waterFallPos += 0.5f;

    riverPos += riverSpeed;
    if (riverPos > 0.5f) riverPos -= 0.5f;

    if (isRaining) {
        rainPos -= rainSpeed;
        if (rainPos < -0.5f) rainPos += 0.5f;
    }

    glutPostRedisplay();
    glutTimerFunc(30, update, 0);
}

// CIRCLE
void drawCircle(GLfloat cx, GLfloat cy, GLfloat r, int num_segments)
{
    GLfloat twicePi = 2.0f * PI;
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(cx, cy);
    for(int i = 0; i <= num_segments; i++)
    {
        glVertex2f( cx + (r * cos(i * twicePi / num_segments)),
                    cy + (r * sin(i * twicePi / num_segments)) );
    }
    glEnd();
}

// DISPLAY
void display()
{
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity();

    // SKY
    if (isRaining) {
        glColor3f(0.25f, 0.50f, 0.70f); // DARK SKY
    } else {
        glColor3f(0.38f, 0.70f, 0.95f); // NORMAL SKY
    }
    glBegin(GL_QUADS);
    glVertex2f(-1.0f, 1.0f);  glVertex2f(1.0f, 1.0f);
    glVertex2f(1.0f, 0.2f);   glVertex2f(-1.0f, 0.2f);
    glEnd();

    // WATERFALL BACKGROUND
    // DARK BLUE PART
    glColor3f(0.18f, 0.52f, 0.78f);
    glBegin(GL_QUADS);
    glVertex2f(-0.30f, 0.52f);
    glVertex2f(0.25f, 0.52f);
    glVertex2f(0.28f, -0.45f);
    glVertex2f(-0.32f, -0.45f);
    glEnd();

    // LIGHT BLUE PART
    glColor3f(0.42f, 0.78f, 0.95f);
    glBegin(GL_QUADS);
    glVertex2f(-0.28f, 0.52f);
    glVertex2f(-0.15f, 0.52f);
    glVertex2f(-0.16f, -0.45f);
    glVertex2f(-0.30f, -0.45f);
    glVertex2f(-0.10f, 0.52f);
    glVertex2f(0.05f, 0.52f);
    glVertex2f(0.06f, -0.45f);
    glVertex2f(-0.12f, -0.45f);
    glVertex2f(0.10f, 0.52f);
    glVertex2f(0.23f, 0.52f);
    glVertex2f(0.25f, -0.45f);
    glVertex2f(0.12f, -0.45f);
    glEnd();

    // MOVING WATER LINES
    glPushMatrix();
    glTranslatef(0.0f, waterFallPos, 0.0f);
    glColor3f(0.85f, 0.95f, 1.0f); // BRIGHT COLOR
    glBegin(GL_QUADS);
    glVertex2f(-0.25f, 1.00f);
    glVertex2f(-0.21f, 1.00f);
    glVertex2f(-0.22f, -0.30f);
    glVertex2f(-0.26f, -0.30f);
    glVertex2f(-0.08f, 0.80f);
    glVertex2f(-0.03f, 0.80f);
    glVertex2f(-0.04f, -0.10f);
    glVertex2f(-0.09f, -0.10f);
    glVertex2f(0.12f, 1.10f);
    glVertex2f(0.17f, 1.10f);
    glVertex2f(0.18f, -0.40f);
    glVertex2f(0.13f, -0.40f);
    glEnd();
    glPopMatrix();

    // WATERFALL TOP
    if (isRaining) {
        glColor3f(0.25f, 0.50f, 0.70f); // MATCH DARK SKY
    } else {
        glColor3f(0.38f, 0.70f, 0.95f);
    }
    glBegin(GL_QUADS);
    glVertex2f(-0.35f, 1.0f);
    glVertex2f(0.35f, 1.0f);
    glVertex2f(0.35f, 0.52f);
    glVertex2f(-0.35f, 0.52f);
    glEnd();

    // CLOUDS AND BIRDS
    glPushMatrix();
    glTranslatef(cloudPosition, 0.0f, 0.0f);
    if (isRaining) glColor3f(0.8f, 0.8f, 0.8f); // DARK CLOUDS
    else glColor3f(1.0f, 1.0f, 1.0f);

    drawCircle(-0.35f, 0.85f, 0.10f, 30);
    drawCircle(-0.25f, 0.88f, 0.13f, 30);
    drawCircle(-0.15f, 0.85f, 0.09f, 30);
    glBegin(GL_QUADS);
    glVertex2f(-0.45f, 0.85f);
    glVertex2f(-0.05f, 0.85f);
    glVertex2f(-0.05f, 0.78f);
    glVertex2f(-0.45f, 0.78f);
    glEnd();

    drawCircle(0.35f, 0.88f, 0.07f, 30);
    drawCircle(0.45f, 0.90f, 0.09f, 30);
    drawCircle(0.53f, 0.88f, 0.06f, 30);
    glBegin(GL_QUADS);
    glVertex2f(0.28f, 0.88f);
    glVertex2f(0.59f, 0.88f);
    glVertex2f(0.59f, 0.83f);
    glVertex2f(0.28f, 0.83f);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(birdPosition, 0.0f, 0.0f);
    glColor3f(0.1f, 0.1f, 0.1f);
    glLineWidth(2.0f);
    glBegin(GL_LINES);
    glVertex2f(-0.55f, 0.88f);
    glVertex2f(-0.50f, 0.84f);
    glVertex2f(-0.50f, 0.84f);
    glVertex2f(-0.45f, 0.88f);

    glVertex2f(-0.05f, 0.92f);
    glVertex2f(0.00f, 0.88f);
    glVertex2f(0.00f, 0.88f);
    glVertex2f(0.05f, 0.92f);

    glVertex2f(0.10f, 0.82f);
    glVertex2f(0.14f, 0.78f);
    glVertex2f(0.14f, 0.78f);
    glVertex2f(0.18f, 0.82f);

    glVertex2f(0.60f, 0.85f);
    glVertex2f(0.64f, 0.81f);
    glVertex2f(0.64f, 0.81f);
    glVertex2f(0.68f, 0.85f);
    glEnd();
    glPopMatrix();

    // BACKGROUND TREES
    glColor3f(0.18f, 0.65f, 0.22f);
    drawCircle(-0.85f, 0.85f, 0.14f, 30);
    drawCircle(-0.70f, 0.88f, 0.16f, 30);
    drawCircle(-0.55f, 0.82f, 0.13f, 30);
    drawCircle(0.70f, 0.85f, 0.13f, 30);
    drawCircle(0.85f, 0.88f, 0.16f, 30);
    drawCircle(0.95f, 0.82f, 0.13f, 30);

    glColor3f(0.55f, 0.27f, 0.12f);
    glBegin(GL_QUADS);
    glVertex2f(-0.73f, 0.75f);
    glVertex2f(-0.67f, 0.75f);
    glVertex2f(-0.65f, 0.50f);
    glVertex2f(-0.75f, 0.50f);
    glVertex2f(0.82f, 0.75f);
    glVertex2f(0.88f, 0.75f);
    glVertex2f(0.90f, 0.50f);
    glVertex2f(0.80f, 0.50f);
    glEnd();

    glColor3f(0.08f, 0.50f, 0.18f);
    drawCircle(-0.95f, 0.60f, 0.15f, 30);
    drawCircle(-0.75f, 0.58f, 0.14f, 30);
    drawCircle(-0.55f, 0.55f, 0.12f, 30);
    drawCircle(0.55f, 0.55f, 0.12f, 30);
    drawCircle(0.75f, 0.58f, 0.14f, 30);
    drawCircle(0.95f, 0.60f, 0.15f, 30);

    // ROCKS
    glColor3f(0.35f, 0.38f, 0.42f);
    glBegin(GL_POLYGON);
    glVertex2f(-1.0f, 0.55f);
    glVertex2f(-0.30f, 0.52f);
    glVertex2f(-0.25f, -0.40f);
    glVertex2f(-1.0f, -0.40f);
    glEnd();

    glColor3f(0.52f, 0.55f, 0.58f);
    glBegin(GL_TRIANGLES);
    glVertex2f(-0.85f, 0.55f);
    glVertex2f(-0.50f, 0.53f);
    glVertex2f(-0.65f, 0.10f);
    glVertex2f(-0.50f, 0.53f);
    glVertex2f(-0.30f, 0.52f);
    glVertex2f(-0.40f, 0.00f);
    glVertex2f(-0.65f, 0.10f);
    glVertex2f(-0.40f, 0.00f);
    glVertex2f(-0.85f, -0.20f);
    glEnd();

    glColor3f(0.30f, 0.32f, 0.36f);
    glBegin(GL_POLYGON);
    glVertex2f(0.25f, 0.52f);
    glVertex2f(1.0f, 0.55f);
    glVertex2f(1.0f, -0.40f);
    glVertex2f(0.28f, -0.40f);
    glEnd();

    glColor3f(0.48f, 0.50f, 0.54f);
    glBegin(GL_TRIANGLES);
    glVertex2f(0.40f, 0.52f);
    glVertex2f(0.75f, 0.54f);
    glVertex2f(0.55f, 0.10f);
    glVertex2f(0.75f, 0.54f);
    glVertex2f(1.0f, 0.55f);
    glVertex2f(0.85f, 0.05f);
    glVertex2f(0.55f, 0.10f);
    glVertex2f(0.85f, 0.05f);
    glVertex2f(0.70f, -0.25f);
    glEnd();

    // WHITE FOAM
    glColor3f(0.95f, 0.98f, 1.0f);
    drawCircle(-0.30f, -0.45f, 0.08f, 30);
    drawCircle(-0.20f, -0.43f, 0.09f, 30);
    drawCircle(-0.08f, -0.42f, 0.10f, 30);
    drawCircle(0.05f, -0.42f, 0.10f, 30);
    drawCircle(0.18f, -0.43f, 0.09f, 30);
    drawCircle(0.28f, -0.45f, 0.08f, 30);
    drawCircle(-0.38f, -0.38f, 0.015f, 10);
    drawCircle(-0.35f, -0.32f, 0.012f, 10);
    drawCircle(0.33f, -0.33f, 0.014f, 10);
    drawCircle(0.38f, -0.39f, 0.015f, 10);

    // WATER AT BOTTOM
    glColor3f(0.12f, 0.54f, 0.85f);
    glBegin(GL_QUADS);
    glVertex2f(-1.0f, -0.45f);
    glVertex2f(1.0f, -0.45f);
    glVertex2f(1.0f, -1.0f);
    glVertex2f(-1.0f, -1.0f);
    glEnd();

    glPushMatrix();
    glTranslatef(riverPos, 0.0f, 0.0f);
    glColor3f(0.35f, 0.72f, 0.95f);
    glBegin(GL_QUADS);
    // MOVING WAVES
    for (float x = -2.0f; x <= 2.0f; x += 0.5f) {

        glVertex2f(x, -0.52f);
        glVertex2f(x + 0.15f, -0.52f);
        glVertex2f(x + 0.15f, -0.54f);
        glVertex2f(x, -0.54f);
        glVertex2f(x + 0.2f, -0.65f);
        glVertex2f(x + 0.40f, -0.65f);
        glVertex2f(x + 0.40f, -0.67f);
        glVertex2f(x + 0.2f, -0.67f);
        glVertex2f(x + 0.1f, -0.75f);
        glVertex2f(x + 0.35f, -0.75f);
        glVertex2f(x + 0.35f, -0.77f);
        glVertex2f(x + 0.1f, -0.77f);
        glVertex2f(x + 0.3f, -0.88f);
        glVertex2f(x + 0.45f, -0.88f);
        glVertex2f(x + 0.45f, -0.90f);
        glVertex2f(x + 0.3f, -0.90f);
    }
    glEnd();
    glPopMatrix();


    glColor3f(0.20f, 0.65f, 0.15f);
    glBegin(GL_POLYGON);
    glVertex2f(-1.0f, -0.40f);
    glVertex2f(-0.65f, -0.45f);
    glVertex2f(-0.55f, -0.65f);
    glVertex2f(-0.80f, -0.85f);
    glVertex2f(-1.0f, -1.0f);
    glEnd();
    glBegin(GL_POLYGON);
    glVertex2f(1.0f, -0.40f);
    glVertex2f(0.60f, -0.45f);
    glVertex2f(0.50f, -0.65f);
    glVertex2f(0.75f, -0.85f);
    glVertex2f(1.0f, -1.0f);
    glEnd();

    glColor3f(0.35f, 0.36f, 0.38f);
    drawCircle(-0.55f, -0.80f, 0.10f, 30);
    drawCircle(-0.70f, -0.88f, 0.09f, 30);
    drawCircle(0.58f, -0.75f, 0.09f, 30);
    drawCircle(0.72f, -0.88f, 0.11f, 30);
    drawCircle(0.85f, -0.75f, 0.12f, 30);

    glColor3f(0.08f, 0.45f, 0.12f);
    glBegin(GL_TRIANGLES);
    glVertex2f(-1.0f, -1.0f);
    glVertex2f(-0.85f, -0.40f);
    glVertex2f(-0.75f, -1.0f);
    glVertex2f(-0.95f, -1.0f);
    glVertex2f(-0.65f, -0.50f);
    glVertex2f(-0.60f, -1.0f);
    glVertex2f(1.0f, -1.0f);
    glVertex2f(0.85f, -0.40f);
    glVertex2f(0.75f, -1.0f);
    glVertex2f(0.95f, -1.0f);
    glVertex2f(0.65f, -0.50f);
    glVertex2f(0.60f, -1.0f);
    glEnd();

    glColor3f(0.22f, 0.72f, 0.18f);
    glBegin(GL_TRIANGLES);
    glVertex2f(-0.98f, -1.0f);
    glVertex2f(-0.82f, -0.45f);
    glVertex2f(-0.78f, -1.0f);
    glVertex2f(-0.90f, -1.0f);
    glVertex2f(-0.62f, -0.58f);
    glVertex2f(-0.68f, -1.0f);
    glVertex2f(0.98f, -1.0f);
    glVertex2f(0.82f, -0.45f);
    glVertex2f(0.78f, -1.0f);
    glVertex2f(0.90f, -1.0f);
    glVertex2f(0.62f, -0.58f);
    glVertex2f(0.68f, -1.0f);
    glEnd();

    // RAIN
    if (isRaining) {
        glPushMatrix();
        glTranslatef(0.0f, rainPos, 0.0f); // STRAIGHT DOWN
        glColor3f(0.8f, 0.9f, 1.0f); // RAIN COLOR
        glLineWidth(1.5f);
        glBegin(GL_LINES);

        // RAIN DROPS
        for (float y = 1.5f; y >= -1.5f; y -= 0.5f) {
            for (float x = -1.2f; x <= 1.2f; x += 0.2f) {
                glVertex2f(x, y);
                glVertex2f(x, y - 0.15f); // STRAIGHT LINE
                glVertex2f(x + 0.1f, y - 0.25f);
                glVertex2f(x + 0.1f, y - 0.40f);
            }
        }
        glEnd();
        glPopMatrix();
    }

    glFlush();
}

// MAIN
int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitWindowSize(1000, 700);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Tahmid Yousuf Prince (22-49637-3)");
    glutDisplayFunc(display);
    PlaySound("a.wav", NULL, SND_ASYNC | SND_FILENAME | SND_LOOP);
    glutKeyboardFunc(handleKeypress);
    glutTimerFunc(30, update, 0);
    glutMainLoop();
    return 0;
}
